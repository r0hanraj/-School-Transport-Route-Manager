import { Link } from "react-router-dom";

function Signup() {

  return (

    <div style={styles.container}>

      <form style={styles.form}>

        <h2>Create Account</h2>

        <input
          type="text"
          placeholder="Enter Name"
          style={styles.input}
        />

        <input
          type="email"
          placeholder="Enter Email"
          style={styles.input}
        />

        <input
          type="password"
          placeholder="Enter Password"
          style={styles.input}
        />

        <input
          type="password"
          placeholder="Confirm Password"
          style={styles.input}
        />

        <button style={styles.button}>Register</button>

        <p>
          Already have an account?
          <Link to="/login"> Login</Link>
        </p>

      </form>

    </div>

  );
}

const styles = {

  container: {
    height: "80vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },

  form: {
    width: "350px",
    padding: "30px",
    background: "#f1f5f9",
    borderRadius: "10px",
    display: "flex",
    flexDirection: "column",
  },

  input: {
    margin: "10px 0",
    padding: "12px",
  },

  button: {
    padding: "12px",
    background: "#2563eb",
    color: "white",
    border: "none",
    marginTop: "10px",
  },

};

export default Signup;