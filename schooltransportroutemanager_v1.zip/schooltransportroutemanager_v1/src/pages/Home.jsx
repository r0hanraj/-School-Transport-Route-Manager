function Home() {

  return (

    <div style={styles.container}>

      {/* HERO SECTION */}

      <section style={styles.hero}>

        <div style={styles.overlay}>

          <h1 style={styles.heading}>
            Smart School Transport Management System
          </h1>

          <p style={styles.subtext}>
            Safe • Secure • Real-Time Transportation Monitoring
          </p>

          <button style={styles.button}>
            Get Started
          </button>

        </div>

      </section>

      {/* FEATURES SECTION */}

      <section style={styles.featuresSection}>

        <h2 style={styles.sectionTitle}>
          Key Features
        </h2>

        <div style={styles.cardContainer}>

          <div style={styles.card}>
            <h3>🚌 Route Optimization</h3>
            <p>
              Efficient route planning for reducing delays and fuel consumption.
            </p>
          </div>

          <div style={styles.card}>
            <h3>📍 Real-Time Tracking</h3>
            <p>
              Monitor school transportation routes with live updates.
            </p>
          </div>

          <div style={styles.card}>
            <h3>🔔 Parent Notifications</h3>
            <p>
              Instant alerts regarding pickup timings and delays.
            </p>
          </div>

          <div style={styles.card}>
            <h3>👨‍💼 Admin Dashboard</h3>
            <p>
              Centralized platform for managing buses and students.
            </p>
          </div>

        </div>

      </section>

      {/* MODULES SECTION */}

      <section style={styles.moduleSection}>

        <h2 style={styles.sectionTitle}>
          Functional Modules
        </h2>

        <div style={styles.moduleContainer}>

          <div style={styles.moduleCard}>
            Route Planning Module
          </div>

          <div style={styles.moduleCard}>
            Student Allocation Module
          </div>

          <div style={styles.moduleCard}>
            Driver Management Module
          </div>

          <div style={styles.moduleCard}>
            Notification Module
          </div>

          <div style={styles.moduleCard}>
            Analytics Dashboard
          </div>

          <div style={styles.moduleCard}>
            Transport History
          </div>

        </div>

      </section>

      {/* FOOTER */}

      <footer style={styles.footer}>

        <h3>School Transport Route Manager</h3>

        <p>
          Front End Development Frameworks and UI Engineering Project
        </p>

      </footer>

    </div>
  );
}

const styles = {

  container: {
    fontFamily: "Arial",
  },

  hero: {
    height: "90vh",
    backgroundImage:
      "linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url('https://images.unsplash.com/photo-1509062522246-3755977927d7?q=80&w=1600&auto=format&fit=crop')",
    backgroundSize: "cover",
    backgroundPosition: "center",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    color: "white",
    textAlign: "center",
  },

  overlay: {
    padding: "20px",
  },

  heading: {
    fontSize: "60px",
    marginBottom: "20px",
  },

  subtext: {
    fontSize: "24px",
    marginBottom: "30px",
  },

  button: {
    padding: "15px 35px",
    background: "#2563eb",
    border: "none",
    color: "white",
    fontSize: "18px",
    borderRadius: "8px",
    cursor: "pointer",
  },

  featuresSection: {
    padding: "80px 50px",
    background: "#f8fafc",
  },

  sectionTitle: {
    textAlign: "center",
    marginBottom: "50px",
    fontSize: "40px",
  },

  cardContainer: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit,minmax(250px,1fr))",
    gap: "30px",
  },

  card: {
    background: "white",
    padding: "30px",
    borderRadius: "15px",
    boxShadow: "0 0 15px rgba(0,0,0,0.1)",
    textAlign: "center",
  },

  moduleSection: {
    padding: "80px 50px",
    background: "#e2e8f0",
  },

  moduleContainer: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit,minmax(250px,1fr))",
    gap: "25px",
  },

  moduleCard: {
    background: "#0f172a",
    color: "white",
    padding: "25px",
    borderRadius: "12px",
    textAlign: "center",
    fontWeight: "bold",
    fontSize: "18px",
  },

  footer: {
    background: "#020617",
    color: "white",
    padding: "30px",
    textAlign: "center",
  },

};

export default Home;