import { Link } from "react-router-dom";

function Login() {

  return (

    <div style={styles.container}>

      <form style={styles.form}>

        <h2>Login</h2>

        <input
          type="email"
          placeholder="Enter Email"
          style={styles.input}
        />

        <input
          type="password"
          placeholder="Enter Password"
          style={styles.input}
        />

        <button style={styles.button}>Login</button>

        <p>
          Don't have an account?
          <Link to="/signup"> Signup</Link>
        </p>

      </form>

    </div>

  );
}

const styles = {

  container: {
    height: "80vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },

  form: {
    width: "350px",
    padding: "30px",
    background: "#f1f5f9",
    borderRadius: "10px",
    display: "flex",
    flexDirection: "column",
  },

  input: {
    margin: "10px 0",
    padding: "12px",
  },

  button: {
    padding: "12px",
    background: "#2563eb",
    color: "white",
    border: "none",
    marginTop: "10px",
  },

};

export default Login;