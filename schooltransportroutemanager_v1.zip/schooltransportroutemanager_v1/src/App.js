import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";

import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Signup from "./pages/Signup";

function App() {

  return (

    <Router>

      <Navbar />

      <Routes>

        <Route path="/" element={<Home />} />

        <Route path="/login" element={<Login />} />

        <Route path="/signup" element={<Signup />} />

        <Route path="/routes" element={<Navigate to="/" />} />

        <Route path="/students" element={<Navigate to="/" />} />

        <Route path="/drivers" element={<Navigate to="/" />} />

        <Route path="/dashboard" element={<Navigate to="/" />} />

      </Routes>

    </Router>

  );
}

export default App;