import { Link } from "react-router-dom";

function Navbar() {

  return (

    <nav style={styles.nav}>

      <h2>School Transport Route Manager</h2>

      <div>

        <Link style={styles.link} to="/">Home</Link>

        <Link style={styles.link} to="/routes">Routes</Link>

        <Link style={styles.link} to="/students">Students</Link>

        <Link style={styles.link} to="/drivers">Drivers</Link>

        <Link style={styles.link} to="/dashboard">Dashboard</Link>

        <Link style={styles.link} to="/login">Login</Link>

        <Link style={styles.link} to="/signup">Signup</Link>

      </div>

    </nav>

  );
}

const styles = {

  nav: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "15px 40px",
    background: "#0f172a",
    color: "white",
  },

  link: {
    margin: "0 10px",
    color: "white",
    textDecoration: "none",
    fontWeight: "bold",
  },

};

export default Navbar;